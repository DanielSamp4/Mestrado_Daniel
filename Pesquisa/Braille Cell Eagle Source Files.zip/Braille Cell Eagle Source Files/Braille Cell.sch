<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="16" fill="1" visible="no" active="no"/>
<layer number="3" name="Route3" color="17" fill="1" visible="no" active="no"/>
<layer number="4" name="Route4" color="18" fill="1" visible="no" active="no"/>
<layer number="5" name="Route5" color="19" fill="1" visible="no" active="no"/>
<layer number="6" name="Route6" color="25" fill="1" visible="no" active="no"/>
<layer number="7" name="Route7" color="26" fill="1" visible="no" active="no"/>
<layer number="8" name="Route8" color="27" fill="1" visible="no" active="no"/>
<layer number="9" name="Route9" color="28" fill="1" visible="no" active="no"/>
<layer number="10" name="Route10" color="29" fill="1" visible="no" active="no"/>
<layer number="11" name="Route11" color="30" fill="1" visible="no" active="no"/>
<layer number="12" name="Route12" color="20" fill="1" visible="no" active="no"/>
<layer number="13" name="Route13" color="21" fill="1" visible="no" active="no"/>
<layer number="14" name="Route14" color="22" fill="1" visible="no" active="no"/>
<layer number="15" name="Route15" color="23" fill="1" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="24" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="Braille Cell">
<packages>
<package name="BRAILLE-6">
<circle x="2.43388125" y="-2.21611875" radius="0.2" width="0.001" layer="48"/>
<circle x="-2.272440625" y="-0.691440625" radius="0.2" width="0.001" layer="48"/>
<circle x="-2.272440625" y="-3.791440625" radius="0.2" width="0.001" layer="48"/>
<circle x="-0.66611875" y="-2.21611875" radius="0.2" width="0.001" layer="48"/>
<circle x="-0.66611875" y="0.88388125" radius="0.2" width="0.001" layer="48"/>
<circle x="2.43388125" y="0.88388125" radius="0.2" width="0.001" layer="48"/>
<circle x="2.43388125" y="3.98388125" radius="0.2" width="0.001" layer="48"/>
<circle x="-2.272440625" y="2.408559375" radius="0.2" width="0.001" layer="48"/>
<circle x="0.827559375" y="-0.691440625" radius="0.2" width="0.001" layer="48"/>
<circle x="-0.66611875" y="3.98388125" radius="0.2" width="0.001" layer="48"/>
<circle x="0.827559375" y="2.408559375" radius="0.2" width="0.001" layer="48"/>
<circle x="0.827559375" y="-3.791440625" radius="0.2" width="0.001" layer="48"/>
<circle x="1.55" y="0" radius="0.55" width="0.001" layer="48"/>
<circle x="-1.55" y="3.1" radius="0.55" width="0.001" layer="48"/>
<circle x="1.55" y="-3.1" radius="0.55" width="0.001" layer="48"/>
<circle x="1.55" y="3.1" radius="0.55" width="0.001" layer="48"/>
<circle x="-1.55" y="0" radius="0.55" width="0.001" layer="48"/>
<circle x="-1.55" y="-3.1" radius="0.55" width="0.001" layer="48"/>
<circle x="0" y="-13.335" radius="0.3" width="0.001" layer="48"/>
<circle x="1.27" y="-13.335" radius="0.3" width="0.001" layer="48"/>
<circle x="-1.27" y="-13.335" radius="0.3" width="0.001" layer="48"/>
<circle x="0" y="-12.065" radius="0.3" width="0.001" layer="48"/>
<circle x="1.27" y="-12.065" radius="0.3" width="0.001" layer="48"/>
<circle x="-1.27" y="-12.065" radius="0.3" width="0.001" layer="48"/>
<circle x="0" y="13.335" radius="0.3" width="0.001" layer="48"/>
<circle x="1.27" y="13.335" radius="0.3" width="0.001" layer="48"/>
<circle x="-1.27" y="13.335" radius="0.3" width="0.001" layer="48"/>
<circle x="0" y="12.065" radius="0.3" width="0.001" layer="48"/>
<circle x="1.27" y="12.065" radius="0.3" width="0.001" layer="48"/>
<circle x="-1.27" y="12.065" radius="0.3" width="0.001" layer="48"/>
<circle x="0" y="7.85" radius="1.05" width="0.001" layer="48"/>
<circle x="0" y="-7.85" radius="1.05" width="0.001" layer="48"/>
<circle x="-2.3" y="5.85" radius="0.8" width="0.001" layer="48"/>
<circle x="2.3" y="-5.85" radius="0.8" width="0.001" layer="48"/>
<wire x1="-2.8" y1="14.85" x2="-3.8" y2="13.85" width="0.001" layer="48" curve="90"/>
<wire x1="-3.8" y1="13.85" x2="-3.8" y2="-13.85" width="0.001" layer="48"/>
<wire x1="-3.8" y1="-13.85" x2="-2.8" y2="-14.85" width="0.001" layer="48" curve="90"/>
<wire x1="-2.8" y1="-14.85" x2="2.8" y2="-14.85" width="0.001" layer="48"/>
<wire x1="2.8" y1="-14.85" x2="3.8" y2="-13.85" width="0.001" layer="48" curve="90"/>
<wire x1="3.8" y1="-13.85" x2="3.8" y2="13.85" width="0.001" layer="48"/>
<wire x1="3.8" y1="13.85" x2="2.8" y2="14.85" width="0.001" layer="48" curve="90"/>
<wire x1="2.8" y1="14.85" x2="-2.8" y2="14.85" width="0.001" layer="48"/>
<pad name="P$1" x="-1.27" y="13.335" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$2" x="1.27" y="-13.335" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$3" x="0" y="13.335" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$4" x="0" y="-13.335" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$5" x="1.27" y="13.335" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$6" x="-1.27" y="-13.335" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$7" x="-1.27" y="12.065" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$8" x="1.27" y="-12.065" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$9" x="0" y="12.065" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$10" x="0" y="-12.065" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$11" x="1.27" y="12.065" drill="0.6" shape="octagon" rot="R270"/>
<pad name="P$12" x="-1.27" y="-12.065" drill="0.6" shape="octagon" rot="R270"/>
<text x="-3.81" y="-16.51" size="1.27" layer="27">&gt;VALUE</text>
<text x="-3.81" y="15.24" size="1.27" layer="25">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="BRAILLE-6">
<wire x1="-10.16" y1="-10.16" x2="-10.16" y2="12.7" width="0.254" layer="94"/>
<wire x1="-10.16" y1="12.7" x2="10.16" y2="12.7" width="0.254" layer="94"/>
<wire x1="10.16" y1="12.7" x2="10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="-10.16" y2="-10.16" width="0.254" layer="94"/>
<pin name="1B" x="-15.24" y="7.62" length="middle"/>
<pin name="2B" x="-15.24" y="0" length="middle"/>
<pin name="3B" x="-15.24" y="-7.62" length="middle"/>
<pin name="4B" x="15.24" y="7.62" length="middle" rot="R180"/>
<pin name="5B" x="15.24" y="0" length="middle" rot="R180"/>
<pin name="6B" x="15.24" y="-7.62" length="middle" rot="R180"/>
<pin name="4A" x="15.24" y="10.16" length="middle" rot="R180"/>
<pin name="5A" x="15.24" y="2.54" length="middle" rot="R180"/>
<pin name="6A" x="15.24" y="-5.08" length="middle" rot="R180"/>
<pin name="1A" x="-15.24" y="10.16" length="middle"/>
<pin name="2A" x="-15.24" y="2.54" length="middle"/>
<pin name="3A" x="-15.24" y="-5.08" length="middle"/>
<text x="-10.16" y="15.24" size="1.778" layer="95">&gt;NAME</text>
<text x="-10.16" y="-15.24" size="1.778" layer="95">&gt;Value</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="BRAILLE-6">
<gates>
<gate name="G$1" symbol="BRAILLE-6" x="0" y="0"/>
</gates>
<devices>
<device name="" package="BRAILLE-6">
<connects>
<connect gate="G$1" pin="1A" pad="P$1"/>
<connect gate="G$1" pin="1B" pad="P$2"/>
<connect gate="G$1" pin="2A" pad="P$3"/>
<connect gate="G$1" pin="2B" pad="P$4"/>
<connect gate="G$1" pin="3A" pad="P$5"/>
<connect gate="G$1" pin="3B" pad="P$6"/>
<connect gate="G$1" pin="4A" pad="P$7"/>
<connect gate="G$1" pin="4B" pad="P$8"/>
<connect gate="G$1" pin="5A" pad="P$9"/>
<connect gate="G$1" pin="5B" pad="P$10"/>
<connect gate="G$1" pin="6A" pad="P$11"/>
<connect gate="G$1" pin="6B" pad="P$12"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="U$1" library="Braille Cell" deviceset="BRAILLE-6" device=""/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="U$1" gate="G$1" x="114.3" y="12.7" smashed="yes">
<attribute name="NAME" x="104.14" y="27.94" size="1.778" layer="95"/>
<attribute name="VALUE" x="104.14" y="-2.54" size="1.778" layer="95"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="1A" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="1A"/>
<wire x1="99.06" y1="22.86" x2="93.98" y2="22.86" width="0.1524" layer="91"/>
<label x="93.98" y="22.86" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="2A" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="2A"/>
<wire x1="99.06" y1="15.24" x2="93.98" y2="15.24" width="0.1524" layer="91"/>
<label x="93.98" y="15.24" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="3A" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="3A"/>
<wire x1="99.06" y1="7.62" x2="93.98" y2="7.62" width="0.1524" layer="91"/>
<label x="93.98" y="7.62" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="4A" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="4A"/>
<wire x1="129.54" y1="22.86" x2="134.62" y2="22.86" width="0.1524" layer="91"/>
<label x="134.62" y="22.86" size="1.778" layer="95" xref="yes"/>
</segment>
</net>
<net name="5A" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="5A"/>
<wire x1="129.54" y1="15.24" x2="134.62" y2="15.24" width="0.1524" layer="91"/>
<label x="134.62" y="15.24" size="1.778" layer="95" xref="yes"/>
</segment>
</net>
<net name="6A" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="6A"/>
<wire x1="129.54" y1="7.62" x2="134.62" y2="7.62" width="0.1524" layer="91"/>
<label x="134.62" y="7.62" size="1.778" layer="95" xref="yes"/>
</segment>
</net>
<net name="1B" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="1B"/>
<wire x1="99.06" y1="20.32" x2="93.98" y2="20.32" width="0.1524" layer="91"/>
<label x="93.98" y="20.32" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="2B" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="2B"/>
<wire x1="99.06" y1="12.7" x2="93.98" y2="12.7" width="0.1524" layer="91"/>
<label x="93.98" y="12.7" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="3B" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="3B"/>
<wire x1="99.06" y1="5.08" x2="93.98" y2="5.08" width="0.1524" layer="91"/>
<label x="93.98" y="5.08" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="4B" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="4B"/>
<wire x1="129.54" y1="20.32" x2="134.62" y2="20.32" width="0.1524" layer="91"/>
<label x="134.62" y="20.32" size="1.778" layer="95" xref="yes"/>
</segment>
</net>
<net name="5B" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="5B"/>
<wire x1="129.54" y1="12.7" x2="134.62" y2="12.7" width="0.1524" layer="91"/>
<label x="134.62" y="12.7" size="1.778" layer="95" xref="yes"/>
</segment>
</net>
<net name="6B" class="0">
<segment>
<pinref part="U$1" gate="G$1" pin="6B"/>
<wire x1="129.54" y1="5.08" x2="134.62" y2="5.08" width="0.1524" layer="91"/>
<label x="134.62" y="5.08" size="1.778" layer="95" xref="yes"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
</eagle>
